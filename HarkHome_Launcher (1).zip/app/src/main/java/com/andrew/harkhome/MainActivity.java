package com.andrew.harkhome;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Hark Home: a minimal Android launcher.
 * Page 1 = clean home (clock + dock). Swipe left for page 2 = widgets. Dock with Apps and the Hark bar on both.
 * Hark slides up from the bottom inside the launcher. Swipe up elsewhere for the app drawer.
 */
public class MainActivity extends Activity {

    // Colors: true blue and black.
    static final int BLUE = Color.parseColor("#0073CF");
    static final int BLUE_DARK = Color.parseColor("#00509A");
    static final int BLACK = Color.BLACK;
    static final int PANEL_BG = Color.parseColor("#E6000000");
    static final int TEXT = Color.parseColor("#F2F6FA");
    static final int MUTED = Color.parseColor("#8FB8E0");

    static final String HARK_URL = "https://app.hark.com";
    static final String HARK_PACKAGE = "com.hark.android";

    static final int HOST_ID = 1024;
    static final int REQ_BIND = 1;
    static final int REQ_CONFIG = 2;
    static final int REQ_MIC = 3;

    AppWidgetManager widgetManager;
    AppWidgetHost widgetHost;
    SharedPreferences prefs;
    int pendingWidgetId = -1;

    FrameLayout root, pages;
    LinearLayout home, homePage, widgetPage, widgetColumn, drawer, harkPanel, dots;
    int currentPage = 0; // 0 = clean home, 1 = widgets
    final ExecutorService bg = Executors.newSingleThreadExecutor();
    final Handler ui = new Handler(Looper.getMainLooper());
    boolean appsLoaded = false;
    BroadcastReceiver packageReceiver;
    GridView appGrid;
    EditText search;
    WebView harkWeb;
    boolean harkLoaded = false;

    final List<AppEntry> allApps = new ArrayList<>();
    final List<AppEntry> shownApps = new ArrayList<>();
    AppAdapter adapter;
    GestureDetector gestures;

    static class AppEntry {
        String label;
        String pkg;
        String cls;
        Drawable icon;
    }

    // ---------- Setup ----------

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("harkhome", MODE_PRIVATE);
        widgetManager = AppWidgetManager.getInstance(this);
        widgetHost = new AppWidgetHost(this, HOST_ID);

        root = new FrameLayout(this);
        buildHome();
        buildDrawer();
        buildHarkPanel();
        setContentView(root);

        restoreWidgets();
        setupGestures();
        loadAppsAsync();

        // Refresh the app list only when apps are installed or removed, not on every Home press.
        packageReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) { loadAppsAsync(); }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(packageReceiver, f);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(packageReceiver); } catch (Exception ignored) { }
        bg.shutdown();
    }

    @Override
    protected void onStart() {
        super.onStart();
        widgetHost.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        try { widgetHost.stopListening(); } catch (Exception ignored) { }
    }

    // Pressing Home while the launcher is open closes the drawer or Hark.
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Snap straight back to the clean home page with no animation, so Home feels instant.
        if (drawer.getVisibility() == View.VISIBLE) { drawer.animate().cancel(); drawer.setVisibility(View.GONE); hideKeyboard(); }
        if (harkPanel.getVisibility() == View.VISIBLE) { harkPanel.animate().cancel(); harkPanel.setVisibility(View.GONE); hideKeyboard(); }
        showPage(0, false);
    }

    @Override
    public void onBackPressed() {
        if (harkPanel.getVisibility() == View.VISIBLE) {
            if (harkWeb != null && harkWeb.canGoBack()) harkWeb.goBack();
            else closeHark();
        } else if (drawer.getVisibility() == View.VISIBLE) {
            closeDrawer();
        } else if (currentPage != 0) {
            showPage(0, true);
        }
        // A launcher never closes itself on Back.
    }

    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    GradientDrawable rounded(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(2), stroke);
        return g;
    }

    // ---------- Home screen ----------

    void buildHome() {
        home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        home.setPadding(dp(16), dp(36), dp(16), dp(16));

        pages = new FrameLayout(this);

        // Page 1: clean home, just the clock and date.
        homePage = new LinearLayout(this);
        homePage.setOrientation(LinearLayout.VERTICAL);

        TextClock time = new TextClock(this);
        time.setFormat12Hour("h:mm");
        time.setFormat24Hour("HH:mm");
        time.setTextSize(64);
        time.setTextColor(Color.WHITE);
        time.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        time.setShadowLayer(8, 0, 2, BLACK);
        homePage.addView(time);

        TextClock date = new TextClock(this);
        date.setFormat12Hour("EEEE, MMMM d");
        date.setFormat24Hour("EEEE, MMMM d");
        date.setTextSize(18);
        date.setTextColor(MUTED);
        date.setShadowLayer(6, 0, 1, BLACK);
        homePage.addView(date);

        time.setOnClickListener(v -> {
            try { startActivity(new Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)); }
            catch (Exception ignored) { }
        });
        time.setOnLongClickListener(v -> { showHomeMenu(); return true; });

        View empty = new View(this);
        empty.setOnLongClickListener(v -> { showHomeMenu(); return true; });
        homePage.addView(empty, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        pages.addView(homePage, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Page 2: widgets.
        widgetPage = new LinearLayout(this);
        widgetPage.setOrientation(LinearLayout.VERTICAL);

        TextView wTitle = new TextView(this);
        wTitle.setText("Widgets");
        wTitle.setTextSize(22);
        wTitle.setTextColor(Color.WHITE);
        wTitle.setTypeface(Typeface.DEFAULT_BOLD);
        wTitle.setShadowLayer(6, 0, 1, BLACK);
        widgetPage.addView(wTitle);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout scrollInner = new LinearLayout(this);
        scrollInner.setOrientation(LinearLayout.VERTICAL);
        widgetColumn = new LinearLayout(this);
        widgetColumn.setOrientation(LinearLayout.VERTICAL);
        widgetColumn.setPadding(0, dp(12), 0, 0);
        scrollInner.addView(widgetColumn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView add = new TextView(this);
        add.setText("+  Add widget");
        add.setTextSize(16);
        add.setTextColor(Color.WHITE);
        add.setGravity(Gravity.CENTER);
        add.setPadding(0, dp(14), 0, dp(14));
        add.setBackground(rounded(Color.parseColor("#99000000"), BLUE, 20));
        add.setOnClickListener(v -> pickWidget());
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        alp.topMargin = dp(4);
        alp.bottomMargin = dp(16);
        scrollInner.addView(add, alp);

        TextView hint = new TextView(this);
        hint.setText("Long-press a widget to resize, move, or remove it.");
        hint.setTextSize(13);
        hint.setTextColor(MUTED);
        hint.setGravity(Gravity.CENTER);
        hint.setShadowLayer(6, 0, 1, BLACK);
        scrollInner.addView(hint);

        scroll.addView(scrollInner, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        widgetPage.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        pages.addView(widgetPage, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        home.addView(pages, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // Page dots.
        dots = new LinearLayout(this);
        dots.setOrientation(LinearLayout.HORIZONTAL);
        dots.setGravity(Gravity.CENTER);
        for (int i = 0; i < 2; i++) {
            View d = new View(this);
            final int page = i;
            d.setOnClickListener(v -> showPage(page, true));
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(8), dp(8));
            dlp.leftMargin = dp(5);
            dlp.rightMargin = dp(5);
            dots.addView(d, dlp);
        }
        LinearLayout.LayoutParams dotsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(24));
        home.addView(dots, dotsLp);

        // Dock: Apps button + Hark bar (on both pages).
        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER_VERTICAL);

        TextView apps = new TextView(this);
        apps.setText("\u2637");
        apps.setTextSize(24);
        apps.setTextColor(Color.WHITE);
        apps.setGravity(Gravity.CENTER);
        apps.setBackground(rounded(BLACK, BLUE, 28));
        apps.setOnClickListener(v -> openDrawer());
        apps.setOnLongClickListener(v -> { showHomeMenu(); return true; });
        dock.addView(apps, new LinearLayout.LayoutParams(dp(56), dp(56)));

        TextView harkBar = new TextView(this);
        harkBar.setText("Ask Hark");
        harkBar.setTextSize(17);
        harkBar.setTextColor(Color.WHITE);
        harkBar.setTypeface(Typeface.DEFAULT_BOLD);
        harkBar.setGravity(Gravity.CENTER);
        harkBar.setBackground(rounded(BLUE, 0, 28));
        harkBar.setOnClickListener(v -> openHark());
        LinearLayout.LayoutParams hb = new LinearLayout.LayoutParams(0, dp(56), 1f);
        hb.leftMargin = dp(12);
        dock.addView(harkBar, hb);

        home.addView(dock, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(home, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Lay pages out once we know the width.
        pages.post(() -> showPage(0, false));
    }

    void showPage(int page, boolean animate) {
        currentPage = page;
        int w = pages.getWidth() > 0 ? pages.getWidth() : getResources().getDisplayMetrics().widthPixels;
        float homeX = -page * w;
        float widgetX = (1 - page) * w;
        homePage.animate().cancel();
        widgetPage.animate().cancel();
        if (animate) {
            homePage.animate().translationX(homeX).setDuration(200).start();
            widgetPage.animate().translationX(widgetX).setDuration(200).start();
        } else {
            homePage.setTranslationX(homeX);
            widgetPage.setTranslationX(widgetX);
        }
        homePage.setVisibility(View.VISIBLE);
        widgetPage.setVisibility(View.VISIBLE);
        for (int i = 0; i < dots.getChildCount(); i++) {
            dots.getChildAt(i).setBackground(rounded(i == page ? BLUE : Color.parseColor("#80FFFFFF"), 0, 4));
        }
    }

    // Swipe up from the bottom edge opens Hark; swipe up anywhere else opens the app drawer.
    void setupGestures() {
        gestures = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null || e2 == null) return false;
                if (drawer.getVisibility() == View.VISIBLE || harkPanel.getVisibility() == View.VISIBLE) return false;
                float dy = e2.getY() - e1.getY();
                float dx = e2.getX() - e1.getX();
                if (Math.abs(dx) > dp(80) && Math.abs(vx) > Math.abs(vy) * 1.5f) {
                    if (dx < 0 && currentPage == 0) showPage(1, true);
                    else if (dx > 0 && currentPage == 1) showPage(0, true);
                    return true;
                }
                if (dy < -dp(80) && Math.abs(vy) > Math.abs(vx)) {
                    if (e1.getY() > root.getHeight() * 0.8f) openHark();
                    else if (currentPage == 0) openDrawer(); // widgets page scrolls instead
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (gestures != null) gestures.onTouchEvent(ev);
        return super.dispatchTouchEvent(ev);
    }

    void showHomeMenu() {
        String[] items = {"Add widget", "Remove a widget", "Change wallpaper", "Choose default home app"};
        new AlertDialog.Builder(this)
                .setTitle("Hark Home")
                .setItems(items, (d, which) -> {
                    if (which == 0) pickWidget();
                    else if (which == 1) removeWidgetDialog();
                    else if (which == 2) {
                        try { startActivity(Intent.createChooser(new Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")); }
                        catch (Exception ignored) { }
                    } else {
                        try { startActivity(new Intent(Settings.ACTION_HOME_SETTINGS)); }
                        catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                    }
                })
                .show();
    }

    // ---------- Widgets (standard Android widgets) ----------

    void pickWidget() {
        final List<AppWidgetProviderInfo> providers = new ArrayList<>(widgetManager.getInstalledProviders());
        final PackageManager pm = getPackageManager();
        Collections.sort(providers, (a, b) -> label(a, pm).compareToIgnoreCase(label(b, pm)));
        String[] names = new String[providers.size()];
        for (int i = 0; i < providers.size(); i++) names[i] = label(providers.get(i), pm);
        new AlertDialog.Builder(this)
                .setTitle("Add widget")
                .setItems(names, (d, which) -> { showPage(1, true); bindWidget(providers.get(which)); })
                .show();
    }

    String label(AppWidgetProviderInfo info, PackageManager pm) {
        String widget = info.loadLabel(pm);
        String app;
        try {
            app = pm.getApplicationLabel(pm.getApplicationInfo(info.provider.getPackageName(), 0)).toString();
        } catch (Exception e) {
            app = info.provider.getPackageName();
        }
        return app.equals(widget) ? app : app + ": " + widget;
    }

    void bindWidget(AppWidgetProviderInfo info) {
        pendingWidgetId = widgetHost.allocateAppWidgetId();
        if (widgetManager.bindAppWidgetIdIfAllowed(pendingWidgetId, info.provider)) {
            configureOrAdd(pendingWidgetId);
        } else {
            // Android asks the user once to allow Hark Home to show widgets.
            Intent bind = new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND);
            bind.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId);
            bind.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider);
            startActivityForResult(bind, REQ_BIND);
        }
    }

    void configureOrAdd(int id) {
        AppWidgetProviderInfo info = widgetManager.getAppWidgetInfo(id);
        if (info != null && info.configure != null) {
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null);
                return;
            } catch (Exception e) {
                // Fall through and add it unconfigured.
            }
        }
        addWidgetView(id, true);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        int id = pendingWidgetId;
        if (data != null) id = data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId);
        if (request == REQ_BIND) {
            if (result == RESULT_OK) configureOrAdd(id);
            else widgetHost.deleteAppWidgetId(id);
        } else if (request == REQ_CONFIG) {
            if (result == RESULT_OK) addWidgetView(id, true);
            else widgetHost.deleteAppWidgetId(id);
        }
    }

    void addWidgetView(int id, boolean save) {
        AppWidgetProviderInfo info = widgetManager.getAppWidgetInfo(id);
        if (info == null) return;
        AppWidgetHostView view = widgetHost.createView(getApplicationContext(), id, info);
        view.setAppWidget(id, info);

        WidgetFrame frame = new WidgetFrame(this);
        frame.setTag(id);
        frame.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        frame.onLongPress = () -> widgetMenu(frame);

        int defH = Math.max(info.minHeight, dp(100));
        int height = prefs.getInt("h_" + id, defH);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height);
        lp.bottomMargin = dp(12);
        widgetColumn.addView(frame, lp);
        reportSize(view, height);
        if (save) saveWidgets();
    }

    // Tells the widget how much room it has so it can show more or less content.
    void reportSize(AppWidgetHostView view, int heightPx) {
        try {
            float d = getResources().getDisplayMetrics().density;
            int wDp = Math.round((getResources().getDisplayMetrics().widthPixels - dp(32)) / d);
            int hDp = Math.round(heightPx / d);
            view.updateAppWidgetSize(null, wDp, hDp, wDp, hDp);
        } catch (Exception ignored) { }
    }

    void widgetMenu(final WidgetFrame frame) {
        String[] items = {"Resize", "Move up", "Move down", "Remove"};
        new AlertDialog.Builder(this)
                .setItems(items, (d, which) -> {
                    int idx = widgetColumn.indexOfChild(frame);
                    if (which == 0) resizeDialog(frame);
                    else if (which == 1 && idx > 0) {
                        widgetColumn.removeView(frame);
                        widgetColumn.addView(frame, idx - 1);
                        saveWidgets();
                    } else if (which == 2 && idx < widgetColumn.getChildCount() - 1) {
                        widgetColumn.removeView(frame);
                        widgetColumn.addView(frame, idx + 1);
                        saveWidgets();
                    } else if (which == 3) {
                        Object tag = frame.getTag();
                        if (tag instanceof Integer) {
                            widgetHost.deleteAppWidgetId((Integer) tag);
                            prefs.edit().remove("h_" + tag).apply();
                        }
                        widgetColumn.removeView(frame);
                        saveWidgets();
                    }
                })
                .show();
    }

    // Live height slider: the widget grows and shrinks as you drag.
    void resizeDialog(final WidgetFrame frame) {
        final int id = (Integer) frame.getTag();
        final LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) frame.getLayoutParams();
        final int min = dp(60);
        final int max = Math.max(dp(200), Math.round(getResources().getDisplayMetrics().heightPixels * 0.75f));
        final int start = lp.height;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(16), dp(24), dp(8));
        final TextView label = new TextView(this);
        label.setTextSize(15);
        box.addView(label);
        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(Math.max(0, Math.min(max - min, start - min)));
        label.setText("Height: " + Math.round(start / getResources().getDisplayMetrics().density) + " dp");
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                lp.height = min + p;
                frame.setLayoutParams(lp);
                label.setText("Height: " + Math.round(lp.height / getResources().getDisplayMetrics().density) + " dp");
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(bar);

        new AlertDialog.Builder(this)
                .setTitle("Resize widget")
                .setView(box)
                .setPositiveButton("Done", (d, w) -> {
                    prefs.edit().putInt("h_" + id, lp.height).apply();
                    if (frame.getChildCount() > 0 && frame.getChildAt(0) instanceof AppWidgetHostView)
                        reportSize((AppWidgetHostView) frame.getChildAt(0), lp.height);
                })
                .setNegativeButton("Cancel", (d, w) -> { lp.height = start; frame.setLayoutParams(lp); })
                .show();
    }

    // Holds one widget and catches a long-press even though the widget handles its own taps.
    static class WidgetFrame extends FrameLayout {
        Runnable onLongPress;
        final Handler h = new Handler(Looper.getMainLooper());
        float downX, downY;
        boolean fired;
        final Runnable trigger = () -> { fired = true; performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS); if (onLongPress != null) onLongPress.run(); };

        WidgetFrame(Context c) { super(c); }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    fired = false;
                    downX = e.getX(); downY = e.getY();
                    h.postDelayed(trigger, android.view.ViewConfiguration.getLongPressTimeout());
                    break;
                case MotionEvent.ACTION_MOVE:
                    float slop = android.view.ViewConfiguration.get(getContext()).getScaledTouchSlop();
                    if (Math.abs(e.getX() - downX) > slop || Math.abs(e.getY() - downY) > slop) h.removeCallbacks(trigger);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    h.removeCallbacks(trigger);
                    break;
            }
            return fired; // after a long-press, swallow the rest so the widget doesn't also get a tap
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) fired = false;
            return true;
        }
    }

    void saveWidgets() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < widgetColumn.getChildCount(); i++) {
            Object tag = widgetColumn.getChildAt(i).getTag();
            if (tag instanceof Integer) {
                if (sb.length() > 0) sb.append(',');
                sb.append(tag);
            }
        }
        prefs.edit().putString("widgets", sb.toString()).apply();
    }

    void restoreWidgets() {
        String saved = prefs.getString("widgets", "");
        if (saved.isEmpty()) return;
        for (String s : saved.split(",")) {
            try { addWidgetView(Integer.parseInt(s.trim()), false); }
            catch (Exception ignored) { }
        }
    }

    void removeWidgetDialog() {
        final int count = widgetColumn.getChildCount();
        if (count == 0) {
            Toast.makeText(this, "No widgets yet", Toast.LENGTH_SHORT).show();
            return;
        }
        PackageManager pm = getPackageManager();
        String[] names = new String[count];
        for (int i = 0; i < count; i++) {
            Object tag = widgetColumn.getChildAt(i).getTag();
            AppWidgetProviderInfo info = tag instanceof Integer ? widgetManager.getAppWidgetInfo((Integer) tag) : null;
            names[i] = info != null ? label(info, pm) : "Widget " + (i + 1);
        }
        new AlertDialog.Builder(this)
                .setTitle("Remove which widget?")
                .setItems(names, (d, which) -> {
                    View v = widgetColumn.getChildAt(which);
                    Object tag = v.getTag();
                    if (tag instanceof Integer) {
                        widgetHost.deleteAppWidgetId((Integer) tag);
                        prefs.edit().remove("h_" + tag).apply();
                    }
                    widgetColumn.removeView(v);
                    saveWidgets();
                })
                .show();
    }

    // ---------- App drawer ----------

    void buildDrawer() {
        drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setBackgroundColor(PANEL_BG);
        drawer.setPadding(dp(12), dp(36), dp(12), dp(8));
        drawer.setVisibility(View.GONE);

        search = new EditText(this);
        search.setHint("Search apps");
        search.setHintTextColor(MUTED);
        search.setTextColor(TEXT);
        search.setSingleLine(true);
        search.setPadding(dp(16), dp(12), dp(16), dp(12));
        search.setBackground(rounded(BLACK, BLUE, 24));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { filterApps(s.toString()); }
            public void afterTextChanged(Editable s) { }
        });
        drawer.addView(search, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        appGrid = new GridView(this);
        appGrid.setNumColumns(4);
        appGrid.setVerticalSpacing(dp(16));
        appGrid.setPadding(0, dp(16), 0, 0);
        appGrid.setClipToPadding(false);
        adapter = new AppAdapter();
        appGrid.setAdapter(adapter);
        appGrid.setOnItemClickListener((p, v, pos, id) -> launch(shownApps.get(pos)));
        appGrid.setOnItemLongClickListener((p, v, pos, id) -> {
            AppEntry a = shownApps.get(pos);
            Intent info = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg));
            startActivity(info);
            return true;
        });
        drawer.addView(appGrid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(drawer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    // Loads the app list off the main thread so pressing Home never waits on it.
    void loadAppsAsync() {
        bg.execute(() -> {
            PackageManager pm = getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
            final List<AppEntry> fresh = new ArrayList<>();
            for (ResolveInfo ri : list) {
                if (ri.activityInfo.packageName.equals(getPackageName())) continue;
                AppEntry a = new AppEntry();
                a.label = ri.loadLabel(pm).toString();
                a.pkg = ri.activityInfo.packageName;
                a.cls = ri.activityInfo.name;
                a.icon = ri.loadIcon(pm);
                fresh.add(a);
            }
            Collections.sort(fresh, (x, y) -> x.label.compareToIgnoreCase(y.label));
            ui.post(() -> {
                allApps.clear();
                allApps.addAll(fresh);
                appsLoaded = true;
                filterApps(search != null ? search.getText().toString() : "");
            });
        });
    }

    void filterApps(String q) {
        shownApps.clear();
        String needle = q.trim().toLowerCase(Locale.ROOT);
        for (AppEntry a : allApps) {
            if (needle.isEmpty() || a.label.toLowerCase(Locale.ROOT).contains(needle)) shownApps.add(a);
        }
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    void launch(AppEntry a) {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setClassName(a.pkg, a.cls);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try { startActivity(i); }
        catch (Exception e) { Toast.makeText(this, "Can't open " + a.label, Toast.LENGTH_SHORT).show(); }
        closeDrawer();
    }

    void openDrawer() {
        closeHark();
        search.setText("");
        drawer.setAlpha(0f);
        drawer.setTranslationY(dp(60));
        drawer.setVisibility(View.VISIBLE);
        drawer.animate().alpha(1f).translationY(0).setDuration(180).start();
    }

    void closeDrawer() {
        if (drawer.getVisibility() != View.VISIBLE) return;
        hideKeyboard();
        drawer.animate().alpha(0f).translationY(dp(60)).setDuration(150)
                .withEndAction(() -> drawer.setVisibility(View.GONE)).start();
    }

    void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
    }

    class AppAdapter extends BaseAdapter {
        public int getCount() { return shownApps.size(); }
        public Object getItem(int p) { return shownApps.get(p); }
        public long getItemId(int p) { return p; }

        public View getView(int p, View convert, ViewGroup parent) {
            LinearLayout cell;
            ImageView icon;
            TextView name;
            if (convert == null) {
                cell = new LinearLayout(MainActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                icon = new ImageView(MainActivity.this);
                cell.addView(icon, new LinearLayout.LayoutParams(dp(52), dp(52)));
                name = new TextView(MainActivity.this);
                name.setTextColor(TEXT);
                name.setTextSize(12);
                name.setGravity(Gravity.CENTER);
                name.setMaxLines(1);
                name.setEllipsize(android.text.TextUtils.TruncateAt.END);
                cell.addView(name, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            } else {
                cell = (LinearLayout) convert;
            }
            icon = (ImageView) cell.getChildAt(0);
            name = (TextView) cell.getChildAt(1);
            AppEntry a = shownApps.get(p);
            icon.setImageDrawable(a.icon);
            name.setText(a.label);
            return cell;
        }
    }

    // ---------- Hark panel (slides up inside the launcher) ----------

    void buildHarkPanel() {
        harkPanel = new LinearLayout(this);
        harkPanel.setOrientation(LinearLayout.VERTICAL);
        harkPanel.setBackgroundColor(BLACK);
        harkPanel.setVisibility(View.GONE);
        harkPanel.setPadding(0, dp(24), 0, 0);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(BLUE);
        header.setPadding(dp(16), dp(10), dp(8), dp(10));

        TextView title = new TextView(this);
        title.setText("Hark");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView openApp = headerButton("Open app");
        openApp.setOnClickListener(v -> openHarkApp());
        header.addView(openApp);

        TextView close = headerButton("\u2715");
        close.setOnClickListener(v -> closeHark());
        header.addView(close);

        harkPanel.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        harkWeb = new WebView(this);
        harkWeb.setBackgroundColor(BLACK);
        WebSettings ws = harkWeb.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(harkWeb, true);

        harkWeb.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                String scheme = req.getUrl().getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                // tel:, mailto:, maps, intent links go to the right app.
                try { startActivity(new Intent(Intent.ACTION_VIEW, req.getUrl())); }
                catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });
        harkWeb.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.getResources());
                    } else {
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                        request.deny();
                    }
                });
            }
        });

        harkPanel.addView(harkWeb, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(harkPanel, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    TextView headerButton(String text) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setPadding(dp(12), dp(6), dp(12), dp(6));
        b.setBackground(rounded(BLUE_DARK, 0, 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }

    void openHark() {
        closeDrawer();
        if (!harkLoaded) {
            harkWeb.loadUrl(HARK_URL);
            harkLoaded = true;
        }
        int h = root.getHeight() > 0 ? root.getHeight() : getResources().getDisplayMetrics().heightPixels;
        harkPanel.setTranslationY(h);
        harkPanel.setVisibility(View.VISIBLE);
        harkPanel.animate().translationY(0).setDuration(250).start();
    }

    void closeHark() {
        if (harkPanel == null || harkPanel.getVisibility() != View.VISIBLE) return;
        hideKeyboard();
        int h = root.getHeight();
        harkPanel.animate().translationY(h).setDuration(200)
                .withEndAction(() -> harkPanel.setVisibility(View.GONE)).start();
    }

    // Opens the installed Hark app, or its Play Store page if it isn't installed.
    void openHarkApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(HARK_PACKAGE);
        if (i == null) {
            i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=" + HARK_PACKAGE));
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); } catch (Exception ignored) { }
    }
}
