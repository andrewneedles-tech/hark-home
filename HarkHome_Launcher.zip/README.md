# Hark Home

A minimal Android launcher in true blue and black.

- Home: big clock and date, your standard Android widgets stacked in a scrolling column, and a dock.
- Dock: Apps button and the Ask Hark bar.
- Hark slides up from the bottom inside the launcher (tap Ask Hark, or swipe up from the bottom edge). "Open app" jumps to the full Hark app.
- Swipe up anywhere else, or tap Apps, for the app drawer with search. Long-press an app for App info.
- Long-press the clock, empty space, or the Apps button for the menu: add widget, remove widget, wallpaper, default home app.
- Back and Home close the drawer or Hark. The launcher never closes itself.

## Build (free, no Android Studio)
1. Put these files in a GitHub repo (keep the folders, including .github/workflows).
2. GitHub builds it automatically on every push (Actions tab > Build Hark Home APK).
3. Open the finished run and download the HarkHome-apk artifact (a zip with app-debug.apk inside).

## Install
1. Open app-debug.apk on the phone and allow installs from that app when asked.
2. Press Home and choose Hark Home, then Always. Or: Settings > Apps > Default apps > Home app > Hark Home.
3. To go back: same setting, pick your old launcher.

Note: Google sign-in is often blocked inside embedded web views. If the Hark panel won't sign in that way, use Open app.
